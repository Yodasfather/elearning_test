# adapt-contrib-core
Adapt Framework kernel. Responsible for boot loading, data loading and core APIs.

Note: In order to facilitate a move away from bower to npm, `src/core` has been moved to this repository.

----------------------------
**Version number:** 6.12.0 <br />
**Framework versions:** 5.20.2 <br />
**Author / maintainer:** Adapt Core Team with [contributors](https://github.com/adaptlearning/adapt-contrib-core/graphs/contributors)
