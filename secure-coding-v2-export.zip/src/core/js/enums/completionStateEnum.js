const COMPLETION_STATE = ENUM([
  'INCOMPLETE',
  'COMPLETED',
  'PASSED',
  'FAILED'
]);

export default COMPLETION_STATE;
