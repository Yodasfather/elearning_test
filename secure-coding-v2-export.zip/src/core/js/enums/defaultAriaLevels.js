export default {
  _menu: 1,
  _menuGroup: 2,
  _menuItem: 2,
  _page: 1,
  _article: 2,
  _block: 3,
  _component: 4,
  _componentItem: 5,
  _notify: 1
};
