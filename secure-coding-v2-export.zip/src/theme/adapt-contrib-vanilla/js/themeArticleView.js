import ThemeView from './themeView';

export default class ThemeArticleView extends ThemeView {

  className() {}

  setCustomStyles() {}

  onRemove() {}

}
